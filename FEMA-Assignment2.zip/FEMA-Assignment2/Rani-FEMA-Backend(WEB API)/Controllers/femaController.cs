﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using RaniFemaAssignment.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace RaniFemaAssignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class femaController : ControllerBase
    {
        private readonly IConfiguration _configuration;


        public femaController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]

        public JsonResult Get()
        {
            string query = @"
                           select* from RaniAssetFemaDetail ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();


                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }

            }
            return new JsonResult(table);
        }

        [HttpPost]
        public JsonResult Post(RaniAssetFemaDetail Rafd)
        {
            string query = @"
                             insert into dbo.RaniAssetFemaDetail(FemaId,NeighborhoodDamageLevelId,NeighborhoodCleanupId,IsPropertyHabitable,
MortgagorPlanRemainPropertyId,HazardInsuranceFieldId,FloodInsuranceFieldId,InsuranceProceedsReceivedId,
InsuranceProceedAmountReceived,
MortgagorPlanToRepairPropertyId,AppliedForGovernmentAssistanceId,GovernmentAssistanceReceivedId,
GovernmentAssistanceAmountReceived,
CurrentPropertyDamageLevelId,EstimatedCostOfDamageId,PropertyCleanupId,RoofDamageId,
RoofTarpedId,MaximumVisibleWaterLineId,WaterLineLengthId,
ConditionsPresentMildewGrowthId,ExplainMildewGrowth,FemaTrailerOnPropertyId)
                             values
(@FemaId,@NeighborhoodDamageLevelId,@NeighborhoodCleanupId,@IsPropertyHabitable,
@MortgagorPlanRemainPropertyId,@HazardInsuranceFieldId,@FloodInsuranceFieldId,
@InsuranceProceedsReceivedId,@InsuranceProceedAmountReceived,
@MortgagorPlanToRepairPropertyId,@AppliedForGovernmentAssistanceId,
@GovernmentAssistanceReceivedId,@GovernmentAssistanceAmountReceived,
@CurrentPropertyDamageLevelId,@EstimatedCostOfDamageId,@PropertyCleanupId,
@RoofDamageId,@RoofTarpedId,@MaximumVisibleWaterLineId,@WaterLineLengthId,
@ConditionsPresentMildewGrowthId,@ExplainMildewGrowth,@FemaTrailerOnPropertyId)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {

                    // myCommand.Parameters.AddWithValue("@TestNumber",emi.TestNumber);
                    myCommand.Parameters.AddWithValue("@FemaId", Rafd.FemaId);
                    myCommand.Parameters.AddWithValue("@NeighborhoodDamageLevelId", Rafd.NeighborhoodDamageLevelId);
                    myCommand.Parameters.AddWithValue("@NeighborhoodCleanupId", Rafd.NeighborhoodCleanupId);
                    myCommand.Parameters.AddWithValue("@IsPropertyHabitable", Rafd.IsPropertyHabitable);
                    myCommand.Parameters.AddWithValue("@MortgagorPlanRemainPropertyId", Rafd.MortgagorPlanRemainPropertyId);
                    myCommand.Parameters.AddWithValue("@HazardInsuranceFieldId", Rafd.HazardInsuranceFieldId);
                    myCommand.Parameters.AddWithValue("@FloodInsuranceFieldId", Rafd.FloodInsuranceFieldId);
                    myCommand.Parameters.AddWithValue("@InsuranceProceedsReceivedId", Rafd.InsuranceProceedsReceivedId);
                    myCommand.Parameters.AddWithValue("InsuranceProceedAmountReceived", Rafd.InsuranceProceedAmountReceived);
                    myCommand.Parameters.AddWithValue("@MortgagorPlanToRepairPropertyId", Rafd.MortgagorPlanToRepairPropertyId);
                    myCommand.Parameters.AddWithValue("@AppliedForGovernmentAssistanceId", Rafd.AppliedForGovernmentAssistanceId);
                    myCommand.Parameters.AddWithValue("@GovernmentAssistanceReceivedId", Rafd.GovernmentAssistanceReceivedId);
                    myCommand.Parameters.AddWithValue("@GovernmentAssistanceAmountReceived", Rafd.GovernmentAssistanceAmountReceived);
                    myCommand.Parameters.AddWithValue("@CurrentPropertyDamageLevelId", Rafd.CurrentPropertyDamageLevelId);
                    myCommand.Parameters.AddWithValue("@EstimatedCostOfDamageId", Rafd.EstimatedCostOfDamageId);
                    myCommand.Parameters.AddWithValue("@PropertyCleanupId", Rafd.PropertyCleanupId);
                    myCommand.Parameters.AddWithValue("@RoofDamageId", Rafd.RoofDamageId);
                    myCommand.Parameters.AddWithValue("@RoofTarpedId", Rafd.RoofTarpedId);
                    myCommand.Parameters.AddWithValue("@MaximumVisibleWaterLineId", Rafd.MaximumVisibleWaterLineId);
                    myCommand.Parameters.AddWithValue("@WaterLineLengthId", Rafd.WaterLineLengthId);
                    myCommand.Parameters.AddWithValue("@ConditionsPresentMildewGrowthId", Rafd.ConditionsPresentMildewGrowthId);
                    myCommand.Parameters.AddWithValue("@ExplainMildewGrowth", Rafd.ExplainMildewGrowth);
                    myCommand.Parameters.AddWithValue("@FemaTrailerOnPropertyId", Rafd.FemaTrailerOnPropertyId);

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }
        [HttpPut]
        public JsonResult Put(RaniAssetFemaDetail Rafd)
        {
            string query = @"
                           update dbo.RaniAssetFemaDetail
                           set FemaId = @FemaId,
                           NeighborhoodDamageLevelId = @NeighborhoodDamageLevelId,
                           NeighborhoodCleanupId = @NeighborhoodCleanupId,
                           IsPropertyHabitable = @IsPropertyHabitable,
                           MortgagorPlanRemainPropertyId = @MortgagorPlanRemainPropertyId,
                           HazardInsuranceFieldId = @HazardInsuranceFieldId,
                           FloodInsuranceFieldId = @FloodInsuranceFieldId,
                           InsuranceProceedsReceivedId = @InsuranceProceedsReceivedId,
                           InsuranceProceedAmountReceived = @InsuranceProceedAmountReceived,
                           MortgagorPlanToRepairPropertyId = @MortgagorPlanToRepairPropertyId,
                           AppliedForGovernmentAssistanceId = @AppliedForGovernmentAssistanceId, 
                           GovernmentAssistanceReceivedId = @GovernmentAssistanceReceivedId,
                           GovernmentAssistanceAmountReceived = @GovernmentAssistanceAmountReceived,
                          CurrentPropertyDamageLevelId = @CurrentPropertyDamageLevelId,
                          EstimatedCostOfDamageId = @EstimatedCostOfDamageId,
                          PropertyCleanupId =@PropertyCleanupId,
                           RoofDamageId = @RoofDamageId,
                            RoofTarpedId = @RoofTarpedId,
                           MaximumVisibleWaterLineId = @MaximumVisibleWaterLineId,
                        WaterLineLengthId = @WaterLineLengthId,
                        ConditionsPresentMildewGrowthId = @ConditionsPresentMildewGrowthId,
                        ExplainMildewGrowth = @ExplainMildewGrowth,
                           FemaTrailerOnPropertyId = @FemaTrailerOnPropertyId
                            where FemaId=@FemaId";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@FemaId", Rafd.FemaId);
                    myCommand.Parameters.AddWithValue("@NeighborhoodDamageLevelId", Rafd.NeighborhoodDamageLevelId);
                    myCommand.Parameters.AddWithValue("@NeighborhoodCleanupId", Rafd.NeighborhoodCleanupId);
                    myCommand.Parameters.AddWithValue("@IsPropertyHabitable", Rafd.IsPropertyHabitable);
                    myCommand.Parameters.AddWithValue("@MortgagorPlanRemainPropertyId", Rafd.MortgagorPlanRemainPropertyId);
                    myCommand.Parameters.AddWithValue("@HazardInsuranceFieldId", Rafd.HazardInsuranceFieldId);
                    myCommand.Parameters.AddWithValue("@FloodInsuranceFieldId", Rafd.FloodInsuranceFieldId);
                    myCommand.Parameters.AddWithValue("@InsuranceProceedsReceivedId", Rafd.InsuranceProceedsReceivedId);
                    myCommand.Parameters.AddWithValue("InsuranceProceedAmountReceived", Rafd.InsuranceProceedAmountReceived);
                    myCommand.Parameters.AddWithValue("@MortgagorPlanToRepairPropertyId", Rafd.MortgagorPlanToRepairPropertyId);
                    myCommand.Parameters.AddWithValue("@AppliedForGovernmentAssistanceId", Rafd.AppliedForGovernmentAssistanceId);
                    myCommand.Parameters.AddWithValue("@GovernmentAssistanceReceivedId", Rafd.GovernmentAssistanceReceivedId);
                    myCommand.Parameters.AddWithValue("@GovernmentAssistanceAmountReceived", Rafd.GovernmentAssistanceAmountReceived);
                    myCommand.Parameters.AddWithValue("@CurrentPropertyDamageLevelId", Rafd.CurrentPropertyDamageLevelId);
                    myCommand.Parameters.AddWithValue("@EstimatedCostOfDamageId", Rafd.EstimatedCostOfDamageId);
                    myCommand.Parameters.AddWithValue("@PropertyCleanupId", Rafd.PropertyCleanupId);
                    myCommand.Parameters.AddWithValue("@RoofDamageId", Rafd.RoofDamageId);
                    myCommand.Parameters.AddWithValue("@RoofTarpedId", Rafd.RoofTarpedId);
                    myCommand.Parameters.AddWithValue("@MaximumVisibleWaterLineId", Rafd.MaximumVisibleWaterLineId);
                    myCommand.Parameters.AddWithValue("@WaterLineLengthId", Rafd.WaterLineLengthId);
                    myCommand.Parameters.AddWithValue("@ConditionsPresentMildewGrowthId", Rafd.ConditionsPresentMildewGrowthId);
                    myCommand.Parameters.AddWithValue("@ExplainMildewGrowth", Rafd.ExplainMildewGrowth);
                    myCommand.Parameters.AddWithValue("@FemaTrailerOnPropertyId", Rafd.FemaTrailerOnPropertyId);



                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");
        }

        [HttpDelete("{FemaId}")]
        public JsonResult Delete(int FemaId)
        {
            string query = @"
                           delete from dbo.RaniAssetFemaDetail
                           where FemaId=@FemaId
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@FemaId", FemaId);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }

    }
}
