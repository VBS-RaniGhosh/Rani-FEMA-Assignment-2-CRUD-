﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RaniFemaAssignment.Models
{
    public partial class AdventureWorks2017Context : DbContext
    {
        public AdventureWorks2017Context()
        {
        }

        public AdventureWorks2017Context(DbContextOptions<AdventureWorks2017Context> options)
            : base(options)
        {
        }

        public virtual DbSet<RaniAssetFemaDetail> RaniAssetFemaDetail { get; set; }
        public virtual DbSet<RaniLkpCostOfDamage> RaniLkpCostOfDamage { get; set; }
        public virtual DbSet<RaniLkpNeighborhoodCleanup> RaniLkpNeighborhoodCleanup { get; set; }
        public virtual DbSet<RaniLkpNeighborhoodDamageLevel> RaniLkpNeighborhoodDamageLevel { get; set; }
        public virtual DbSet<RaniLkpRoofDamage> RaniLkpRoofDamage { get; set; }
        public virtual DbSet<RaniLkpWaterLineLength> RaniLkpWaterLineLength { get; set; }
        public virtual DbSet<RaniLkpYesNo> RaniLkpYesNo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=192.168.1.230;user=trainee2022;password=trainee@2022;database=AdventureWorks2017");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RaniAssetFemaDetail>(entity =>
            {
                entity.HasKey(e => e.FemaId)
                    .HasName("PK__RaniAsse__EE45F14033998D4C");

                entity.Property(e => e.FemaId).ValueGeneratedNever();

                entity.Property(e => e.ExplainMildewGrowth)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsPropertyHabitable)
                    .HasMaxLength(5)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RaniLkpCostOfDamage>(entity =>
            {
                entity.HasKey(e => e.EstimatedCostOfDamageTypeId)
                    .HasName("PK__RaniLkpC__8632C1E1D5DD1A06");

                entity.Property(e => e.EstimatedCostOfDamageTypeId).ValueGeneratedNever();

                entity.Property(e => e.EstimatedCostOfDamageValue)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpCostOfDamage)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpCo__Damag__36870511");
            });

            modelBuilder.Entity<RaniLkpNeighborhoodCleanup>(entity =>
            {
                entity.HasKey(e => e.CleanupTypeId)
                    .HasName("PK__RaniLkpN__A3F6481D072CAD8E");

                entity.Property(e => e.CleanupTypeId).ValueGeneratedNever();

                entity.Property(e => e.CleanupValues)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpNeighborhoodCleanup)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpNe__Damag__2A212E2C");
            });

            modelBuilder.Entity<RaniLkpNeighborhoodDamageLevel>(entity =>
            {
                entity.HasKey(e => e.DamageLevelTypeId)
                    .HasName("PK__RaniLkpN__1C55E2E8CD4889FC");

                entity.Property(e => e.DamageLevelTypeId).ValueGeneratedNever();

                entity.Property(e => e.DamageLevelValues)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpNeighborhoodDamageLevel)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpNe__Damag__246854D6");
            });

            modelBuilder.Entity<RaniLkpRoofDamage>(entity =>
            {
                entity.HasKey(e => e.RoofDamageTypeId)
                    .HasName("PK__RaniLkpR__503F58277E5D578E");

                entity.Property(e => e.RoofDamageTypeId).ValueGeneratedNever();

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofDamageValue)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpRoofDamage)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpRo__Damag__2744C181");
            });

            modelBuilder.Entity<RaniLkpWaterLineLength>(entity =>
            {
                entity.HasKey(e => e.WaterLineLengthTypeId)
                    .HasName("PK__RaniLkpW__90D2248A52B4BB96");

                entity.Property(e => e.WaterLineLengthTypeId).ValueGeneratedNever();

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.WaterLineLengthValue)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpWaterLineLength)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpWa__Damag__32B6742D");
            });

            modelBuilder.Entity<RaniLkpYesNo>(entity =>
            {
                entity.HasKey(e => e.LkpId)
                    .HasName("PK__RaniLkpY__9C6E09437D9849D7");

                entity.Property(e => e.LkpId).ValueGeneratedNever();

                entity.Property(e => e.IsDeleted)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Lkpvalues)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Damage)
                    .WithMany(p => p.RaniLkpYesNo)
                    .HasForeignKey(d => d.DamageId)
                    .HasConstraintName("FK__RaniLkpYe__Damag__2CFD9AD7");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
