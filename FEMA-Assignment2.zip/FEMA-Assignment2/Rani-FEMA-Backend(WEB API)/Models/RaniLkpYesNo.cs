﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniLkpYesNo
    {
        public int LkpId { get; set; }
        public string Lkpvalues { get; set; }
        public string IsDeleted { get; set; }
        public int? DamageId { get; set; }

        public virtual RaniAssetFemaDetail Damage { get; set; }
    }
}
