﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniAssetFemaDetail
    {
        public RaniAssetFemaDetail()
        {
            RaniLkpCostOfDamage = new HashSet<RaniLkpCostOfDamage>();
            RaniLkpNeighborhoodCleanup = new HashSet<RaniLkpNeighborhoodCleanup>();
            RaniLkpNeighborhoodDamageLevel = new HashSet<RaniLkpNeighborhoodDamageLevel>();
            RaniLkpRoofDamage = new HashSet<RaniLkpRoofDamage>();
            RaniLkpWaterLineLength = new HashSet<RaniLkpWaterLineLength>();
            RaniLkpYesNo = new HashSet<RaniLkpYesNo>();
        }

        public int FemaId { get; set; }
        public int? NeighborhoodDamageLevelId { get; set; }
        public int? NeighborhoodCleanupId { get; set; }
        public string IsPropertyHabitable { get; set; }
        public int? MortgagorPlanRemainPropertyId { get; set; }
        public int? HazardInsuranceFieldId { get; set; }
        public int? FloodInsuranceFieldId { get; set; }
        public int? InsuranceProceedsReceivedId { get; set; }
        public int? InsuranceProceedAmountReceived { get; set; }
        public int? MortgagorPlanToRepairPropertyId { get; set; }
        public int? AppliedForGovernmentAssistanceId { get; set; }
        public int? GovernmentAssistanceReceivedId { get; set; }
        public int? GovernmentAssistanceAmountReceived { get; set; }
        public int? CurrentPropertyDamageLevelId { get; set; }
        public int? EstimatedCostOfDamageId { get; set; }
        public int? PropertyCleanupId { get; set; }
        public int? RoofDamageId { get; set; }
        public int? RoofTarpedId { get; set; }
        public int? MaximumVisibleWaterLineId { get; set; }
        public int? WaterLineLengthId { get; set; }
        public int? ConditionsPresentMildewGrowthId { get; set; }
        public string ExplainMildewGrowth { get; set; }
        public int? FemaTrailerOnPropertyId { get; set; }

        public virtual ICollection<RaniLkpCostOfDamage> RaniLkpCostOfDamage { get; set; }
        public virtual ICollection<RaniLkpNeighborhoodCleanup> RaniLkpNeighborhoodCleanup { get; set; }
        public virtual ICollection<RaniLkpNeighborhoodDamageLevel> RaniLkpNeighborhoodDamageLevel { get; set; }
        public virtual ICollection<RaniLkpRoofDamage> RaniLkpRoofDamage { get; set; }
        public virtual ICollection<RaniLkpWaterLineLength> RaniLkpWaterLineLength { get; set; }
        public virtual ICollection<RaniLkpYesNo> RaniLkpYesNo { get; set; }
    }
}
