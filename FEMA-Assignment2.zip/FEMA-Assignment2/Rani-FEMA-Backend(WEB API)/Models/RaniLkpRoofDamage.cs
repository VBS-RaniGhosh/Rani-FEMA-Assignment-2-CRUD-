﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniLkpRoofDamage
    {
        public int RoofDamageTypeId { get; set; }
        public string RoofDamageValue { get; set; }
        public string IsDeleted { get; set; }
        public int? DamageId { get; set; }

        public virtual RaniAssetFemaDetail Damage { get; set; }
    }
}
