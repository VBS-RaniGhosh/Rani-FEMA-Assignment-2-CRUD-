﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniLkpWaterLineLength
    {
        public int WaterLineLengthTypeId { get; set; }
        public string WaterLineLengthValue { get; set; }
        public string IsDeleted { get; set; }
        public int? DamageId { get; set; }

        public virtual RaniAssetFemaDetail Damage { get; set; }
    }
}
