﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniLkpCostOfDamage
    {
        public int EstimatedCostOfDamageTypeId { get; set; }
        public string EstimatedCostOfDamageValue { get; set; }
        public string IsDeleted { get; set; }
        public int? DamageId { get; set; }

        public virtual RaniAssetFemaDetail Damage { get; set; }
    }
}
