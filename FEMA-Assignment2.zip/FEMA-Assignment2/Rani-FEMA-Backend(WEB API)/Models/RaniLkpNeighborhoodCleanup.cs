﻿using System;
using System.Collections.Generic;

namespace RaniFemaAssignment.Models
{
    public partial class RaniLkpNeighborhoodCleanup
    {
        public int CleanupTypeId { get; set; }
        public string CleanupValues { get; set; }
        public string IsDeleted { get; set; }
        public int? DamageId { get; set; }

        public virtual RaniAssetFemaDetail Damage { get; set; }
    }
}
