// import React, { Component } from "react";




// const API_URL = "https://localhost:44382/api/fema";
// export class Home extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             Datadetails: [],

//         }
//     }
//     refreshList() {
//         fetch('API_URL',
//             {
//                 method: 'POST',
//                 headers: {
//                     'Accept': 'application/json',
//                     'Content-Type': 'application/json'
//                 },
//                 body: JSON.stringify({
//                     neighborhoodDamageLevelId: this.state.neighborhoodDamageLevelId,

//                 })
//             });
//     }




//     componentDidMount() {
//         this.refreshList();
//     }
//     ChangeNeighborhoodDamage = (e)=>{
//     this.setState({ neighborhoodDamageLevelId: e.target.value });
//     }


// render(){
//     const one = 1;
//     const { Datadetails } = this.state;
//     return (<React.Fragment>

//         <h1>FEMA</h1>
//         {/* <h5>Current value {value}</h5> */}

//         <div>
//             <label> 1Current Neighborhood Damage Level </label>
//             <span>
//                 <input type="radio" name="NeighborhoodDamage" value={one} onChange={this.ChangeNeighborhoodDamage} />
//                 <label>Light</label>
//             </span>
//             <span>
//                 <input type="radio" name="NeighborhoodDamage" value="NeighborhoodDamage2" />
//                 <label>Moderate</label>
//             </span>
//             <span>
//                 <input type="radio" name="NeighborhoodDamage" value="NeighborhoodDamage3" />
//                 <label>Severe</label>
//             </span>
//             <span>
//                 <input type="radio" name="NeighborhoodDamage" value="NeighborhoodDamage4" />
//                 <label>Total Loss</label>
//             </span>
//         </div>
//         <div>
//             <label> 2 Current Neighborhood Clean-up </label>
//             <span>
//                 <input type="radio" name="NeighborhoodCleanup" value="NeighborhoodCleanup1" />
//                 <label>In Progress</label>
//             </span>
//             <span>
//                 <input type="radio" name="NeighborhoodCleanup" value="NeighborhoodCleanup2" />
//                 <label>Completed</label>
//             </span>
//             <span>
//                 <input type="radio" name="NeighborhoodCleanup" value="NeighborhoodCleanup3" />
//                 <label>None Progress</label>
//             </span>

//         </div>
//         <div>
//             <label> 3 Is Property Habitable? </label>
//             <span>
//                 <input type="radio" name="IsPropertyHabitable" value="IsPropertyHabitable1" />
//                 <label>In Progress</label>
//             </span>
//             <span>
//                 <input type="radio" name="IsPropertyHabitable" value="NeighborhoodCleanup2" />
//                 <label>Completed</label>
//             </span>


//         </div>
//         <div>
//             <label> 4 Does Mortgagor Plan to Remain in Property?</label>
//             <span>
//                 <input type="radio" name="MortgagorRemain" value="MortgagorRemain1" />
//                 <label>Unknown</label>
//             </span>
//             <span>
//                 <input type="radio" name="MortgagorRemain" value="MortgagorRemain2" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="MortgagorRemain" value="MortgagorRemain3" />
//                 <label>No</label>
//             </span>
//         </div>
//         {value === 'MortgagorRemain2' && (
//             <div>
//                 <label> 5 Hazard Insurance Filed?</label>
//                 <span>
//                     <input type="radio" name="HazardInsuranceFiled" value="HazardInsuranceFiled1" />
//                     <label>Yes</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="HazardInsuranceFiled" value="HazardInsuranceFiled2" />
//                     <label>No</label>
//                 </span><br></br>

//                 <label> 6 Flood Insurance Filed?</label>
//                 <span>
//                     <input type="radio" name="FloodInsuranceFiled" value="FloodInsuranceFiled1" />
//                     <label>Yes</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="FloodInsuranceFiled" value="FloodInsuranceFiled2" />
//                     <label>No</label>
//                 </span>
//             </div>


//         )}

//         <div>
//             <label> 7 Insurance Proceeds Received? </label>
//             <span>
//                 <input type="radio" name="InsuranceProceedsReceived" value="InsuranceProceedsReceived1" />
//                 <label>Unknown</label>
//             </span>
//             <span>
//                 <input type="radio" name="InsuranceProceedsReceived" value="InsuranceProceedsReceived2" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="InsuranceProceedsReceived" value="InsuranceProceedsReceived3" />
//                 <label>No</label>
//             </span>

//         </div>
//         {value === 'InsuranceProceedsReceived2' && (
//             <div>
//                 <label> 8 Amount Received</label>
//                 <span>
//                     <label>Amount Received</label>
//                     <input type="textbox" name="AmountReceived" value=" " />

//                 </span>

//             </div>


//         )}
//         <div>
//             <label> 9 Does Mortgagor Plan to Repair Property? </label>
//             <span>
//                 <input type="radio" name="MortgagorRepair" value="MortgagorRepair1" />
//                 <label>Unknown</label>
//             </span>
//             <span>
//                 <input type="radio" name="MortgagorRepair" value="MortgagorRepair2" />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="MortgagorRepair" value="MortgagorRepair3" />
//                 <label>No</label>
//             </span>


//         </div>
//         <div>
//             <label> 10 Applied for Government Assistance?</label>
//             <span>
//                 <input type="radio" name="AppliedforGovernment" value="AppliedforGovernment1" />
//                 <label>Unknown</label>
//             </span>
//             <span>
//                 <input type="radio" name="AppliedforGovernment" value="AppliedforGovernment2" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="AppliedforGovernment" value="AppliedforGovernment3" />
//                 <label>No</label>
//             </span>


//         </div>
//         {value === 'AppliedforGovernment2' && (
//             <div>
//                 <label> 11 Government Assistance Received?</label>

//                 <span>
//                     <input type="radio" name="AssistanceReceived" value="AssistanceReceived1" />
//                     <label>Unknown</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="AssistanceReceived" value="AssistanceReceived2" />
//                     <label>Yes</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="AssistanceReceived" value="AssistanceReceived3" />
//                     <label>No</label>
//                 </span><br></br>

//                 <label> 12 Amount Received</label>
//                 <span>
//                     <label>Amount Received</label>
//                     <input type="textbox" name="AmountReceived" value=" " />

//                 </span>
//             </div>


//         )}
//         <div>
//             <label> 13 Current Property Damage Level</label>
//             <span>
//                 <input type="radio" name="PropertyDamage" value="PropertyDamage1" />
//                 <label>Light</label>
//             </span>
//             <span>
//                 <input type="radio" name="PropertyDamage" value="PropertyDamage2" />
//                 <label>Moderate</label>
//             </span>
//             <span>
//                 <input type="radio" name="PropertyDamage" value="PropertyDamage3" />
//                 <label>Severe</label>
//             </span>
//             <span>
//                 <input type="radio" name="NPropertyDamage" value="PropertyDamage4" />
//                 <label>Total Loss</label>
//             </span>

//         </div>

//         <div>
//             <label> 14 Estimated Cost of Damage</label>
//             <span>
//                 <input type="radio" name="CostOfDamage" value="CostOfDamage1" />
//                 <label>Under $10,000</label>
//             </span>
//             <span>
//                 <input type="radio" name="CostOfDamage" value="CostOfDamage2" />
//                 <label>$11,000 - $25,000</label>
//             </span>
//             <span>
//                 <input type="radio" name="PCostOfDamage" value="CostOfDamage3" />
//                 <label> $26,000-$75,000</label>
//             </span>
//             <span>
//                 <input type="radio" name="CostOfDamage" value="PCostOfDamage4" />
//                 <label>$76,000-$125,000</label>
//             </span>
//             <span>
//                 <input type="radio" name="CostOfDamage" value="PCostOfDamage4" />
//                 <label>$126,000-$200,000</label>
//             </span>
//             <span>
//                 <input type="radio" name="CostOfDamage10" value="CostOfDamage1" />
//                 <label>Over $200,000</label>
//             </span>

//         </div>
//         <div>
//             <label> 15 Property Clean-up </label>
//             <span>
//                 <input type="radio" name="PropertyCleanup" value="PropertyCleanup1" />
//                 <label>In Progress</label>
//             </span>
//             <span>
//                 <input type="radio" name="PropertyCleanup" value="PropertyCleanup2" />
//                 <label>Completed</label>
//             </span>
//             <span>
//                 <input type="radio" name="PropertyCleanup" value="PropertyCleanup3" />
//                 <label>None Progress</label>
//             </span>

//         </div>
//         <div>
//             <label> 16 Roof Damage</label>
//             <span>
//                 <input type="radio" name="RoofDamage" value="RoofDamage1" />
//                 <label>Under 25%</label>
//             </span>
//             <span>
//                 <input type="radio" name="RoofDamage" value="RoofDamage2" />
//                 <label>26%-50%</label>
//             </span>
//             <span>
//                 <input type="radio" name="RoofDamage" value="RoofDamage3" />
//                 <label>51%-75%</label>
//             </span>
//             <span>
//                 <input type="radio" name="RoofDamage" value="RoofDamage4" />
//                 <label>Over 75%</label>
//             </span>
//             <span>
//                 <input type="radio" name="RoofDamage" value="RoofDamage4" />
//                 <label>None</label>
//             </span>


//         </div>
//         <div>
//             <label>17 Roof Tarped </label>
//             <span>
//                 <input type="radio" name="RoofTarped" value="RoofTarped1" />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="RoofTarped" value="RoofTarped2" />
//                 <label>No</label>
//             </span>
//         </div>
//         <div>
//             <label> 18 Maximum Visible Water Line </label>
//             <span>
//                 <input type="radio" name="VisibleWaterLine" value="VisibleWaterLine1" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="RVisibleWaterLine" value="VisibleWaterLine2" />
//                 <label>No</label>
//             </span>
//         </div>

//         {value === 'VisibleWaterLine1' && (
//             <div>
//                 <label> 19 Water Line Is </label>
//                 <span>
//                     <input type="radio" name="WaterLineIs" value="WaterLineIs1" />
//                     <label>1-3 feet</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="WaterLineIs" value="WaterLineIs2" />
//                     <label>4-8 feet</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="WaterLineIs" value="WaterLineIs3" />
//                     <label>Over 8 feet</label>
//                 </span>

//             </div>


//         )}
//         <div>
//             <label> 20 Conditions Present for Mildew Growth? </label>
//             <span>
//                 <input type="radio" name="ConditionsMildewGrowth" value="ConditionsMildewGrowth1" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="ConditionsMildewGrowth" value="ConditionsMildewGrowth2" />
//                 <label>No</label>
//             </span>
//         </div>
//         {value === 'ConditionsMildewGrowth1' && (
//             <div>
//                 <label> 21 Explain Mildew Growth </label>
//                 <span>
//                     <input type="radio" name="ExplainMildewGrowth" value="ExplainMildewGrowth1" onChange={this.onchange} />
//                     <label>Yes</label>
//                 </span>
//                 <span>
//                     <input type="radio" name="ExplainMildewGrowth" value="ExplainMildewGrowth2" />
//                     <label>No</label>
//                 </span>
//             </div>


//         )}
//         <div>
//             <label> 22 FEMA Trailer on Property  </label>
//             <span>
//                 <input type="radio" name="FEMAonProperty" value="FEMAonProperty1" onChange={this.onchange} />
//                 <label>Yes</label>
//             </span>
//             <span>
//                 <input type="radio" name="FEMAonProperty" value="FEMAonProperty2" />
//                 <label>No</label>
//             </span>
//         </div>

//         <div
//             className="footer"
//             style={{
//                 paddingTop: "40px",
//                 paddingLeft: "100px"
//             }}
//         >
//             <span>
//                 <button className="btn">Submit</button>
//             </span>
//             <span>
//                 <button className="btn1">Reset</button>
//             </span>
//         </div>


//     </React.Fragment>)

// }
// }

// export default Home;