import React, { Component } from "react";

const SaveUser = (e) => {
    e.preventDefault();
    let user = {
    value: ''
    };
    

}

class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state={ value: '' }
}
componentDidMount() {
    // Simple POST request with a JSON body using axios
    // const article = { title: 'React POST Request Example' };
    // axios.post('https://localhost:44382/api/fema', )
    //     .then(response => this.setState({ articleId: response.data.id }));
}



onchange = e => {
    this.setState({ value: e.target.value });
}


render(){
    const {value} = this.state;
    return(<React.Fragment>

        <h1>FEMA</h1>
        {/* <h5>Current value { value }</h5> */}
       
<form action="/" method="post">
    <div  className="OuterBox"
>
        <div >
            <label className="Field0"> FemaId<font className="star">
                *</font>
                </label>
                    <span>
                        <input  className="input0" type="number" name="FemaId" placeholder="FemaId" />
                        
                    </span>
                    </div>
        <div>
            <label className="Field"> Current Neighborhood Damage Level<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodDamage" value={1} />
                        <label>Light</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodDamage" value={2} />
                        <label>Moderate</label>
                    </span >
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodDamage" value={3} />
                        <label>Severe</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodDamage" value={4} />
                        <label>Total Loss</label>
                    </span>
        </div>
        <div>
            <label className="Field">  Current Neighborhood Clean-up<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodCleanup" value={1} />
                        <label>In Progress</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodCleanup" value={2} />
                        <label>Completed</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="NeighborhoodCleanup" value={3} />
                        <label>None Progress</label>
                    </span>
                    
        </div>
        <div>
            <label className="Field">  Is Property Habitable?<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="IsPropertyHabitable" value="Yes" />
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="IsPropertyHabitable" value="No" />
                        <label>No</label>
                    </span>
                    
                    
        </div>
        <div>
            <label className="Field">  Does Mortgagor Plan to Remain in Property?<font className="star">
                *</font></label>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRemain" value={0} />
                        <label>Unknown</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRemain" value="MortgagorRemain2" onChange={this.onchange}/>
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRemain" value={2} />
                        <label>No</label>
                    </span>
                </div>
                { value==='MortgagorRemain2' &&(
                    <div>
                        <label className="InnerField">  Hazard Insurance Filed?</label>
                        <span className="InnerInput">
                        <input type="radio" name="HazardInsuranceFiled" value={1} />
                        <label>Yes</label>
                    </span>
                    <span className="InnerInput"> 
                        <input type="radio" name="HazardInsuranceFiled" value={2} />
                        <label>No</label>
                    </span><br/>

                    <label className="InnerField">  Flood Insurance Filed?</label>
                        <span className="InnerInput">
                        <input type="radio" name="FloodInsuranceFiled" value={1} />
                        <label>Yes</label>
                    </span>
                    <span className="InnerInput">
                        <input type="radio" name="FloodInsuranceFiled" value={2} />
                        <label>No</label>
                    </span>
                    </div>
                    
                      
                )}
                
                 <div>
            <label className="Field">  Insurance Proceeds Received?<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="InsuranceProceedsReceived" value={0} />
                        <label>Unknown</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="InsuranceProceedsReceived" value="InsuranceProceedsReceived2" onChange={this.onchange}/>
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="InsuranceProceedsReceived" value={3} />
                        <label>No</label>
                    </span>
                    
        </div>
        { value==='InsuranceProceedsReceived2' &&(
                    <div>
                        <label className="InnerField">  Amount Received</label>
                        <span className="InnerInput">
                        <label>Amount Received</label>
                        <input type="number" name="AmountReceived" placeholder="Amount Received" />
                        
                     </span>
                    
                    </div>
                    
                      
                )}
        <div>
            <label className="Field">  Does Mortgagor Plan to Repair Property?<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRepair" value={0} />
                        <label>Unknown</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRepair" value="MortgagorRepair2" />
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="MortgagorRepair" value={3} />
                        <label>No</label>
                    </span>
                    
                    
        </div>
        <div>
            <label className="Field">  Applied for Government Assistance?<font className="star">
                *</font></label>
                    <span className="inputs">
                        <input type="radio" name="AppliedforGovernment" value={0}/>
                        <label>Unknown</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="AppliedforGovernment" value="AppliedforGovernment2"  onChange={this.onchange}/>
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="AppliedforGovernment" value={3} />
                        <label>No</label>
                    </span>
                    
                    
        </div>
        { value==='AppliedforGovernment2' &&(
                    <div>
                        <label className="InnerField">  Government Assistance Received?</label>
                        
                    <span className="InnerInput">
                        <input type="radio" name="AssistanceReceived" value={0}/>
                        <label>Unknown</label>
                        </span>
                    <span className="InnerInput">
                        <input type="radio" name="AssistanceReceived" value="AssistanceReceived2" />
                        <label>Yes</label>
                    </span>
                    <span className="InnerInput">
                        <input type="radio" name="AssistanceReceived" value={3}/>
                        <label>No</label>
                    </span><br></br>

                    <label className="InnerField">  Amount Received</label>
                        <span className="InnerInput">
                        <label>Amount Received</label>
                        <input type="number" name="AmountReceived" placeholder="Amount Recived" />
                        
                     </span>
                    </div>
                    
                      
                )}
                 <div>
            <label className="Field">  Current Property Damage Level<font className="star">
                *</font></label>
            <span className="inputs">
                        <input type="radio" name="PropertyDamage" value={1} />
                        <label>Light</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="PropertyDamage" value={2}/>
                        <label>Moderate</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="PropertyDamage" value={3} />
                        <label>Severe</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="NPropertyDamage" value={4} />
                        <label>Total Loss</label>
                    </span>     
                    
        </div>

        <div>
            <label className="Field">  Estimated Cost of Damage<font className="star">
                *</font></label>
                    <span className="inputs">
                        <input type="radio" name="CostOfDamage" value={1} />
                        <label>Under $10,000</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="CostOfDamage" value={2} />
                        <label>$11,000 - $25,000</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="PCostOfDamage" value={3}/>
                        <label> $26,000-$75,000</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="CostOfDamage" value={4} />
                        <label>$76,000-$125,000</label>
                    </span>  
                    <span className="inputs">
                        <input type="radio" name="CostOfDamage" value={5} />
                        <label>$126,000-$200,000</label>
                    </span>    
                    <span className="inputs">
                        <input type="radio" name="CostOfDamage10" value={6} />
                        <label>Over $200,000</label>
                    </span> 
                    
        </div>
        <div>
            <label className="Field15">  Property Clean-up<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="PropertyCleanup" value={1} />
                        <label>In Progress</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="PropertyCleanup" value={2} />
                        <label>Completed</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="PropertyCleanup" value={3} />
                        <label>None Progress</label>
                    </span>
                    
        </div>
        <div>
            <label className="Field16">  Roof Damage<font className="star">
                *</font></label>
                    <span className="inputs">
                        <input type="radio" name="RoofDamage" value={1} />
                        <label>Under 25%</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="RoofDamage" value={2}/>
                        <label>26%-50%</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="RoofDamage" value={3} />
                        <label>51%-75%</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="RoofDamage" value={4}/>
                        <label>Over 75%</label>
                    </span>  
                    <span className="inputs">
                        <input type="radio" name="RoofDamage" value={5} />
                        <label>None</label>
                    </span>    
                   
                    
        </div>
        <div>
        <label className="Field17"> Roof Tarped<font className="star">
                *</font> </label>
                        <span className="inputs">
                        <input type="radio" name="RoofTarped" value={1} />
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="RoofTarped" value={2}/>
                        <label>No</label>
                    </span>
        </div>
        <div>
        <label className="Field">  Maximum Visible Water Line<font className="star">
                *</font> </label>
                    <span className="inputs"> 
                        <input type="radio" name="VisibleWaterLine" value="VisibleWaterLine1" onChange={this.onchange}/>
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="RVisibleWaterLine" value={2} />
                        <label>No</label>
                    </span>
                 </div>
            
        { value==='VisibleWaterLine1' &&(
                    <div>
                    <label className="InnerField"> 19 Water Line Is </label>
                            <span className="InnerInput">
                                <input type="radio" name="WaterLineIs" value={1} />
                                <label>1-3 feet</label>
                            </span>
                            <span className="InnerInput">
                                <input type="radio" name="WaterLineIs" value={2} />
                                <label>4-8 feet</label>
                            </span>
                            <span className="InnerInput">
                                <input type="radio" name="WaterLineIs" value={3} />
                                <label>Over 8 feet</label>
                            </span>
                            
                </div>
                    
                      
                )}
             <div>
                <label className="Field">  Conditions Present for Mildew Growth?<font className="star">
                *</font> </label>
                    <span className="inputs">
                        <input type="radio" name="ConditionsMildewGrowth" value="ConditionsMildewGrowth1" onChange={this.onchange}/>
                        <label>Yes</label>
                    </span>
                    <span className="inputs">
                        <input type="radio" name="ConditionsMildewGrowth" value={2} />
                        <label>No</label>
                    </span>
                 </div>
                 { value==='ConditionsMildewGrowth1' &&(
                    <div>
                    <label className="InnerField">  Explain Mildew Growth </label>
                        <span className="InnerInput">
                            <input type="text" name="ExplainMildewGrowth" placeholder="Explain Mildew Growth"/>
                            
                        </span>
                       
                     </div>
                    
                      
                )}
                 <div>
                    <label className="Field22">  FEMA Trailer on Property<font className="star">
                *</font>  </label>
                        <span className="inputs">
                            <input type="radio" name="FEMAonProperty" value="FEMAonProperty1" onChange={this.onchange}/>
                            <label>Yes</label>
                        </span>
                        <span className="inputs">
                            <input type="radio" name="FEMAonProperty" value={2} />
                            <label>No</label>
                        </span>
                     </div>

                     <div
          className="footer"
          style={{
            paddingTop: "40px",
            paddingLeft: "100px"
          }}
        >
          <div>
              <button type="submit" className="button1">Save</button>
          </div>

          <span>
            <button type="reset" className="button">Reset</button>
          </span>
        </div>
        </div>
      </form>

    </React.Fragment>)
    
}
}
export default Home;