import { Component } from "react";
import React from 'react';

const API_URL = "https://localhost:44382/api/fema";
export class RaniTable extends Component {
    constructor(props) {
        super(props);
        this.state = {
            Datadetails: [],
            
        }
    }
    refreshList() {
        fetch(API_URL)
            .then(response => response.json())
            .then(data => {
                const k = JSON.stringify(data);
                this.setState({Datadetails:JSON.parse(k)});
                console.log(k);
            });

    }
    componentDidMount() {
        this.refreshList();
    }

    
        render(){
            const {
                Datadetails
            }=this.state
            return (
                <div>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th>FemaId</th>
                                <th>NeighborhoodDamageLevelId</th>
                                <th>NeighborhoodCleanupId</th>
                               
                                <th>IsPropertyHabitable</th>
                                <th>MortgagorPlanRemainPropertyId</th>
                                <th>HazardInsuranceFieldId</th>

                                <th>FloodInsuranceFieldId</th>
                                <th>InsuranceProceedsReceivedId</th>
                                <th>InsuranceProceedAmountReceived</th>

                                <th>MortgagorPlanToRepairPropertyId</th>
                                <th>AppliedForGovernmentAssistanceId</th>
                                <th>GovernmentAssistanceReceivedId</th>

                                <th>GovernmentAssistanceAmountReceived</th>
                                <th>CurrentPropertyDamageLevelId</th>
                                <th>EstimatedCostOfDamageId</th>

                                <th>PropertyCleanupId</th>
                                <th>RoofDamageId</th>
                                <th>RoofTarpedId</th>

                                <th>MaximumVisibleWaterLineId</th>
                                <th>WaterLineLengthId</th>
                                <th>ConditionsPresentMildewGrowthId</th>

                                <th>ExplainMildewGrowth</th>
                                <th>FemaTrailerOnPropertyId</th>
                            </tr>
                        </thead>
                        <tbody>
                         { Datadetails.map((user) => 
                            
(
                                    <tr key={user.femaId}>
                                        <td>{user.femaId}</td>
                                        <td>{user.neighborhoodDamageLevelId}</td>
                                        <td>{user.neighborhoodCleanupId}</td>

                                        <td>{user.isPropertyHabitable}</td>
                                        <td>{user.mortgagorPlanRemainPropertyId}</td>
                                        <td>{user.hazardInsuranceFieldId}</td>

                                        <td>{user.floodInsuranceFieldId}</td>
                                        <td>{user.insuranceProceedsReceivedId}</td>
                                        <td>{user.insuranceProceedAmountReceived}</td>

                                        <td>{user.mortgagorPlanToRepairPropertyId}</td>
                                        <td>{user.appliedForGovernmentAssistanceId}</td>
                                        <td>{user.governmentAssistanceReceivedId}</td>

                                        <td>{user.governmentAssistanceAmountReceived}</td>
                                        <td>{user.currentPropertyDamageLevelId}</td>
                                        <td>{user.estimatedCostOfDamageId}</td>

                                        <td>{user.propertyCleanupId}</td>
                                        <td>{user.roofDamageId}</td>
                                        <td>{user.roofTarpedId}</td>

                                        <td>{user.maximumVisibleWaterLineId}</td>
                                        <td>{user.waterLineLengthId}</td>
                                        <td>{user.conditionsPresentMildewGrowthId}</td>

                                        <td>{user.explainMildewGrowth}</td>
                                        <td>{user.femaTrailerOnPropertyId}</td> 
                                </tr>)
        
                                 )}
                        </tbody>
                    </table>
                </div>
            )

        }
    }
