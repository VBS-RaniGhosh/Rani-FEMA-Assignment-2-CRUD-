import logo from './logo.svg';
import './App.css';
import Home from './Component/Home';
import { RaniTable } from './Component/RaniTable';




function App() {
  return (
    <div className="App">
         
      <Home /><br></br><br></br>



      <RaniTable />
      
     
     
    
    </div>
  );
}

export default App;